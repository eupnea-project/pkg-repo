/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_X86_ENCLU_H
#define _ASM_X86_ENCLU_H

#define EENTER	0x02
#define ERESUME	0x03
#define EEXIT	0x04

#endif /* _ASM_X86_ENCLU_H */
