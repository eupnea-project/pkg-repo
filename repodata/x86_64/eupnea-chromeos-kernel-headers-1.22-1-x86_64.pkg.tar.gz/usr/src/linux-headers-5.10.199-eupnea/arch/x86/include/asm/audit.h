/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_X86_AUDIT_H
#define _ASM_X86_AUDIT_H

int ia32_classify_syscall(unsigned int syscall);

#endif /* _ASM_X86_AUDIT_H */
