/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_X86_SHMPARAM_H
#define _ASM_X86_SHMPARAM_H

#define SHMLBA PAGE_SIZE	 /* attach addr a multiple of this */

#endif /* _ASM_X86_SHMPARAM_H */
